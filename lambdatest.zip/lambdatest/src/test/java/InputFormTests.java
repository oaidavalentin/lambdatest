import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.InputFormDemo;
import java.lang.AssertionError;

public class InputFormTests extends BasePage {
    private InputFormDemo InputFormDemo;
    private final By InputFormDemoLink = By.linkText("Input Form Submit");

    @BeforeMethod
    public void setUp() {
        super.setUp();
        InputFormDemo = new InputFormDemo(driver);
    }
    @Test
    public void FirstTestOfThePageInputFromSubmit(){
        driver.findElement(InputFormDemoLink).click();
        InputFormDemo.enterTextinTextFieldname("Oaida Valentin");
        InputFormDemo.enterTextinTextFieldemail("oaidavalentin@yahoo.com");
        InputFormDemo.enterTextinTextFieldpassword("Mira2009..");
        InputFormDemo.enterTextinTextFieldcompany("FastTrackIt");
        InputFormDemo.enterTextinTextFieldwebsite("www.google.ro");
        InputFormDemo.ClickOntheRomaniaoption();
        InputFormDemo.enterTextinTextFieldcity("Alba Iulia");
        InputFormDemo.enterTextinTextFieldaddress1("Strada Vai");
        InputFormDemo.enterTextinTextFieldaddress2("Numarul 7");
        InputFormDemo.enterTextinTextFieldstate("RO");
        InputFormDemo.enterTextinTextFieldszip("517424");


        InputFormDemo.clickOnSubmit();
        String actualResult = driver.findElement(By.cssSelector("#__next > div > section.mt-50 > div > div > div > div > p")).getText();
        System.out.println(actualResult);
        Assert.assertTrue(actualResult.contains("Thanks for contacting us, we will get back to you shortly."));
    }
}
