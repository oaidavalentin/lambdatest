package pages;
import java.awt.*;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InputFormDemo extends BasePage {
    public InputFormDemo(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    @FindBy(id = "name")
    private WebElement textField3;
    public void enterTextinTextFieldname(String name) {
        textField3.sendKeys(name);
    }
    @FindBy(id = "inputEmail4")
    private WebElement textField4;
    public void enterTextinTextFieldemail(String email) {
        textField4.sendKeys(email);
    }

    @FindBy(id = "inputPassword4")
    private WebElement textField5;
    public void enterTextinTextFieldpassword(String pass) {
        textField5.sendKeys(pass);
    }

    @FindBy(id = "company")
    private WebElement textField6;
    public void enterTextinTextFieldcompany(String comp) {
        textField6.sendKeys(comp);
    }

    @FindBy(id = "websitename")
    private WebElement textField7;

    public void enterTextinTextFieldwebsite(String web) {
        textField7.sendKeys(web);
    }

    @FindBy(xpath = "//*[@id=\"seleniumform\"]/div[3]/div[1]/select/option[184]")
    private WebElement textField8;
    public void enterTextinTextFieldcountry(String country) {
        textField8.sendKeys(country);
    }

    @FindBy(id = "inputCity")
    private WebElement textField9;

    public void enterTextinTextFieldcity(String city) {
        textField9.sendKeys(city);
    }

    @FindBy(id = "inputAddress1")
    private WebElement textField10;

    public void enterTextinTextFieldaddress1(String address1) {
        textField10.sendKeys(address1);
    }

    @FindBy(id = "inputAddress2")
    private WebElement textField11;
    public void enterTextinTextFieldaddress2(String address2) {
        textField11.sendKeys(address2);
    }

    @FindBy(id = "inputState")
    private WebElement textField12;
    public void enterTextinTextFieldstate(String state) {
        textField12.sendKeys(state);
    }

    @FindBy(id = "inputZip")
    private WebElement textField13;
    public void enterTextinTextFieldszip(String zip) {
        textField13.sendKeys(zip);
    }

    @FindBy(xpath = "//*[@id=\"seleniumform\"]/div[3]/div[1]/select")
    private WebElement Submit;
    public void ClickOntheRomaniaoption(){
        driver.findElement(By.xpath("//*[@id=\"seleniumform\"]/div[3]/div[1]/select/option[184]")).click();
    }

    public void clickOnSubmit()
    {
        Submit.click();
    }


}
